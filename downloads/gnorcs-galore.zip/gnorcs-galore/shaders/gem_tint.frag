/**
 * @file gem_tint.frag
 * @brief Shade the one enemy of a group that still carries the gem.
 *
 * The mod's refine callback claims only those mobys and hands each one a
 * colour; every other moby declines and keeps stock shading. The tint
 * multiplies the texel so the model's own shading, shadowing and texture
 * detail all survive - the enemy reads as the same creature in a different
 * hue, not as a flat silhouette.
 *
 * Alpha is passed through untouched: the engine reads it for the
 * transparent-texel discard and the semi-transparency marker, and another
 * mod (curved-world) uses it as a depth tag.
 */
#version 450
#extension GL_GOOGLE_include_directive : require
#include "openpete_psx_material.glsl"

layout(set = 3, binding = 1, std140) uniform op_instance {
    vec4 tint;   /**< rgb multiplier; a = strength, 0 = no change. */
};

vec4 op_material(vec4 base)
{
#ifdef OP_PROFILE_TERRAIN
    /* The retained-terrain compile of this source: the selector takes the
     * moby channel only, so this half never draws, but it must compile. */
    return base;
#else
    vec3 shaded = base.rgb * tint.rgb;
    return vec4(clamp(mix(base.rgb, shaded, tint.a), 0.0, 1.0), base.a);
#endif
}
