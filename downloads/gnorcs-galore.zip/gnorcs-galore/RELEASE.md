# Gnorcs Galore — Enemy Multiplier

**Spyro's levels, with a lot more to fight.**

Pick a multiplier and every enemy in the level gets company. 2x doubles them.
5x turns a lone Gnorc into a gang waiting on the castle lawn.

![A pack of Gnorcs charging Spyro](screenshots/01-horde.png)

## Why I made it

I kept seeing the power-up and god-like ability mods people are building for
OpenPete, and I wanted a mod that could really put those powers to the test.
A super-charged flame is a lot more fun when there's a crowd to use it on.

## Clearing a level now means clearing it

A level isn't finished when you've collected every gem and freed every
dragon. You also have to put down every enemy in it — **all of them, copies
included**. At 3x a level with 11 enemies asks for 33. Kill the last one and
the screen says so:

**ALL GNORCS DOWN** — and the level is logged as cleared for good.

The game's own completion percentage is held one short of full until every
level is cleared, so 100% now means gems, dragons **and** Gnorcs. There are
927 enemies across 29 levels waiting for you.

A counter in the corner tracks the level you're in, every enemy in it:
`GNORCS 24/33 72%`.

## Your gems are safe

Only one enemy in each group carries the gem — the original. The copies
fight exactly the same but pay nothing, so the level's gem count, its chests
and its gem total are untouched. More fight, not more loot.

The one with the gem is tinted a random colour, so you can always see which
one is worth killing.

![The tinted gem carrier among its copies](screenshots/02-gem-carrier.png)

## Before and after

![Stock next to 6x](screenshots/03-before-after.png)

## Smart placement

Copies don't just stack on top of each other. Each one is placed around the
original using the game's own collision checks, so nothing spawns inside a
wall or on the far side of one. In tight rooms the mod places fewer rather
than putting an enemy somewhere you can't reach.

![A gang in Dark Hollow](screenshots/04-dark-hollow.png)

## Settings

All in the Mods panel (press **M**), live:

| Setting | Does |
| --- | --- |
| **Enemy multiplier** | 1–6. How many of each enemy the level gets |
| **Spacing** | How tightly the copies pack around the original |
| **Mark the gem carrier** | Random shade, random shiny colour, or off |
| **On-screen counter** | Show the kill counter |
| **Counter position** | Bottom left, bottom centre or bottom right |
| **Pool slots kept free** | How much room to leave the game for dropped gems |
| **Enemies count towards 100%** | The completion rule above; turn off to leave the game's scoring alone |
| **Also in flight levels** | Off by default |

**F7** re-runs the pass for the level you're in.

## Good to know

- The game has a fixed budget for things it can spawn, so on big levels a 4x
  or more may add fewer copies than asked. The panel tells you when that
  happens.
- Enemies that appear partway through a level aren't multiplied — the pass
  runs when the level starts.
- Fodder is left alone. If it drops a butterfly, it isn't an enemy.
- Enemies respawn when you re-enter a level, as they always have, and so do
  the copies after a death. The counter follows the level as it stands;
  clearing one is recorded once and stays recorded.

**Requires:** OpenPete v0.4.2, Spyro the Dragon (NTSC-U).
Drop the `gnorcs-galore` folder into `mods/`.
