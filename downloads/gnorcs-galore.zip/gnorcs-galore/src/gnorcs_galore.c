/**
 * @file gnorcs_galore.c
 * @brief Gnorcs Galore - an enemy multiplier.
 *
 * Every enemy in a level is copied `enemy.multiplier` times. The copies
 * fight exactly like the original but carry no gem, so a level's gem total
 * and its 100% are untouched: only the fight gets bigger. The one enemy of
 * each group that still has the gem is tinted a random shade so it can be
 * picked out, and a counter tracks how many of the level's enemies are
 * down.
 *
 * WHAT COUNTS AS AN ENEMY
 *
 * A moby whose m_DropMoby names a gem (classes 83..87, the same numbers in
 * every level measured), minus a list of containers and props that also
 * drop gems: chests, pots, stone slabs and the invisible trigger mobys.
 * Fodder that drops a butterfly (class 16) is not an enemy, which is the
 * rule the sheep, frogs and birds fall under.
 *
 * HOW A COPY IS MADE (measured; mods/gnorcs-galore/README.md has the story)
 *
 *   1. g_SpawnMoby, the level overlay's own spawner, for a pool slot.
 *   2. The original's props block copied into this mod's guest arena, so
 *      the two never share state.
 *   3. memcpy of the whole Moby struct.
 *   4. Put back what belongs to the new moby: m_MobyIndex, m_Props,
 *      m_CollisionRegion, m_SectorIndex, m_CollisionGroup and
 *      m_CollisionChainNext (overwriting that last one breaks the game's
 *      collision chain and hangs it a few ticks later).
 *   5. m_Pod = 0xFF, or the copy counts as a member of a gang whose roster
 *      does not list it and never gets updated: drawn, but a statue.
 *   6. m_DropMoby = 0xFF so the copy pays no gem.
 *
 * PLACEMENT
 *
 * Copies go on a ring around the original, each candidate tested with the
 * game's own collision calls: func_8004BE4C for a clear spot and
 * func_8004AE38 for line of sight back to the original, so a copy cannot
 * land inside a wall or on the far side of one. When nothing passes, that
 * copy is skipped: fewer enemies beats one stuck in a cliff.
 */

#include <openpete_mod_api.h>
#include <openpete_sdk_symbols.h>
#include <openpete_game_structs.h>
#include <psx_runtime.h>

#include <stdio.h>
#include <string.h>

/* The game's completion percentage (src/completion.c): gems, dragons and
 * eggs, in. Hooked so it also wants the Gnorcs dead. */
#define FN_COMPLETION   0x8002BB20u

/* Collision helpers (asm/collision.s), both measured nonzero = blocked. */
#define FN_SPHERE_HIT   0x8004BE4Cu   /* (Vector3D* pos, int rMoby, int rTerrain) */
#define FN_LINE_BLOCKED 0x8004AE38u   /* (Vector3D* from, Vector3D* to)           */

enum {
    GEM_CLASS_LO = 83,     /* red, green, blue, gold, pink: the same ids in  */
    GEM_CLASS_HI = 87,     /* every level checked                            */
    MAX_ENEMIES  = 128,    /* the level's own enemies, tracked for the count  */
    MAX_COPIES   = 192,    /* what this mod added, watched for a pool reset   */
    SETTLE_TICKS = 24,     /* let the level finish starting before spawning  */
};

/**
 * @brief Every level's enemy count, by the rule below.
 *
 * Counted once with the mod itself, level by level, so the mod can show
 * how much of the game is cleared without having to visit a level first.
 * 927 enemies over 29 levels; the flight levels and Gnorc Gnexus have
 * none that pay a gem.
 */
typedef struct { short id, total; } level_row_t;
static const level_row_t k_levels[] = {
    { 10, 14 }, { 11, 11 }, { 12, 16 }, { 13, 12 }, { 14, 27 }, { 15,  0 },
    { 20, 28 }, { 21, 46 }, { 22, 25 }, { 23, 26 }, { 24, 21 }, { 25,  0 },
    { 30, 32 }, { 31, 41 }, { 32, 27 }, { 33, 41 }, { 34, 22 }, { 35,  0 },
    { 40, 18 }, { 41, 51 }, { 42, 66 }, { 43, 44 }, { 44, 40 }, { 45,  0 },
    { 50, 23 }, { 51, 70 }, { 52, 46 }, { 53, 55 }, { 54, 27 }, { 55,  0 },
    { 60,  0 }, { 61, 42 }, { 62, 35 }, { 63,  4 }, { 64, 17 },
};
#define LEVEL_ROWS ((int)(sizeof k_levels / sizeof *k_levels))

/** Gem-dropping mobys that are scenery, not enemies (measured in Stone Hill,
 * Dry Canyon and Tree Tops, where these class ids are the same objects). */
static const short k_props[] = { 9, 13, 33, 110, 120, 174, 194, 195, 421 };

static const openpete_mod_api_t* g_api;
static openpete_mod_t*           g_self;

/* Settings. */
static int g_multiplier, g_spread, g_reserve, g_mark, g_hud, g_flight_ok, g_debug;
static int g_gate;      /**< enemy.gate_completion. */
static int g_hud_anchor;    /**< 0 bottom-left, 1 bottom-centre, 2 bottom-right. */

/* Guest-side scratch: two Vector3Ds for the collision calls, then props
 * copies for everything spawned this level. */
static uint32_t g_arena, g_arena_size, g_arena_used;
static uint32_t g_vec_a, g_vec_b;

/* Per-level state. */
static int      g_level = -1;
static int      g_ticks;
static int      g_done;            /**< The multiply pass has run.        */
static int32_t  g_dyn_after;       /**< Pool count just after it ran.     */
/* The count is every enemy in the level, copies included. The originals
 * are read straight from the game, which remembers them as dead by itself.
 * A copy has to be latched when it dies, because its slot is freed shortly
 * after and may be handed to something else - and because a death or a
 * reload throws the whole dynamic pool away at once, which must read as "the
 * copies are gone", not as "the player killed thirty Gnorcs in one tick". */
static uint32_t g_track[MAX_ENEMIES];
static short    g_track_class[MAX_ENEMIES];
static int      g_track_n, g_killed;
static uint32_t g_copy[MAX_COPIES];
static short    g_copy_class[MAX_COPIES];
static uint8_t  g_copy_dead[MAX_COPIES];
static int      g_copy_n;
static int      g_added;
static char     g_hud_text[48];
static uint8_t  g_level_cleared[LEVEL_ROWS];  /**< Persisted, see clear_load. */
static int      g_banner_ticks;               /**< Ticks left on the banner. */
static int      g_this_level_row = -1;
static int      g_completion_hooked;
static volatile int g_req_redo;
static int      g_redo_key_held;
static uint32_t g_rng = 0x1234567u;
static int g_rej_space, g_rej_sight, g_cand;   /**< Placement stats, debug.log. */

static uint32_t rnd(void)
{
    g_rng ^= g_rng << 13; g_rng ^= g_rng >> 17; g_rng ^= g_rng << 5;
    return g_rng;
}

static int in_gameplay(void)
{
    const int32_t* gs = (const int32_t*)g_api->guest(OP_GADDR_g_Gamestate);
    return gs && *gs == 0;
}

static Moby* level_mobys(void)
{
    const uint32_t* head = (const uint32_t*)g_api->guest(OP_GADDR_g_LevelMobys);
    if (!head || (*head >> 24) != 0x80u) return NULL;
    return (Moby*)g_api->guest(*head);
}

/** The level's own mobys end where the dynamic pool begins. */
static int level_moby_count(Moby* mobys)
{
    const uint32_t* dyn = (const uint32_t*)g_api->guest(OP_GADDR_g_DynMobys);
    uint32_t end = (dyn && (*dyn >> 24) == 0x80u) ? *dyn : 0;
    int n = 0;
    while (mobys && n < 1024 && mobys[n].m_State != 0xFF) {
        if (end && g_api->guest_addr(&mobys[n]) >= end) break;
        n++;
    }
    return n;
}

static int is_gem(int cls) { return cls >= GEM_CLASS_LO && cls <= GEM_CLASS_HI; }

static int is_prop(short cls)
{
    for (unsigned i = 0; i < sizeof k_props / sizeof *k_props; i++)
        if (k_props[i] == cls) return 1;
    return 0;
}

/**
 * @brief An enemy: pays a gem when killed, and is not itself a pickup,
 *        container or prop.
 *
 * A gem moby sometimes carries a gem drop class of its own (Ice Cavern has
 * a cluster of them), so gems have to be ruled out by their own class as
 * well, or the mod would quietly multiply the level's gems and break its
 * 100%.
 */
static int is_enemy(const Moby* m)
{
    return is_gem(m->m_DropMoby) && !is_gem(m->m_Class) && !is_prop(m->m_Class);
}

static uint32_t arena_take(uint32_t size)
{
    size = (size + 3u) & ~3u;
    if (!g_arena || g_arena_used + size > g_arena_size) return 0;
    uint32_t at = g_arena + g_arena_used;
    g_arena_used += size;
    return at;
}

/**
 * @brief Size of a level moby's props block, from the gap to the next one.
 *
 * Level mobys' props sit one after another in the level data in ascending
 * order, so the nearest block above is where this one ends.
 */
static uint32_t props_size(const Moby* src, Moby* mobys, int n)
{
    uint32_t base = src->m_Props, best = 0;
    if (!base) return 0;
    for (int i = 0; i < n; i++) {
        uint32_t p = mobys[i].m_Props;
        if (p > base && (best == 0 || p < best)) best = p;
    }
    uint32_t size = best ? best - base : 0;
    if (size == 0 || size > 512) size = 64;
    return size;
}

static void put_vec(uint32_t at, int32_t x, int32_t y, int32_t z)
{
    int32_t* v = (int32_t*)g_api->guest(at);
    if (v) { v[0] = x; v[1] = y; v[2] = z; }
}

/** Free space for a moby of this radius, by the game's own sphere test. */
static int spot_is_clear(CPUState* cpu, const Moby* like, int32_t x, int32_t y, int32_t z)
{
    if (!g_vec_a) return 1;
    put_vec(g_vec_a, x, y, z);
    int r = like->m_RenderRadius ? like->m_RenderRadius * 8 : 256;
    if (r > 400) r = 400;
    uint32_t a0 = cpu->a0, a1 = cpu->a1, a2 = cpu->a2, v0 = cpu->v0;
    cpu->a0 = g_vec_a; cpu->a1 = (uint32_t)r; cpu->a2 = (uint32_t)r;
    g_api->call(cpu, FN_SPHERE_HIT);
    uint32_t hit = cpu->v0;
    cpu->a0 = a0; cpu->a1 = a1; cpu->a2 = a2; cpu->v0 = v0;
    return hit == 0;
}

/** Line of sight from the original to the spot: keeps copies in the room. */
static int spot_in_sight(CPUState* cpu, const Moby* src, int32_t x, int32_t y, int32_t z)
{
    if (!g_vec_a || !g_vec_b) return 1;
    put_vec(g_vec_a, src->m_Position.x, src->m_Position.y, src->m_Position.z + 200);
    put_vec(g_vec_b, x, y, z + 200);
    uint32_t a0 = cpu->a0, a1 = cpu->a1, v0 = cpu->v0;
    cpu->a0 = g_vec_a; cpu->a1 = g_vec_b;
    g_api->call(cpu, FN_LINE_BLOCKED);
    uint32_t blocked = cpu->v0;
    cpu->a0 = a0; cpu->a1 = a1; cpu->v0 = v0;
    return blocked == 0;
}

/* 4096ths of a circle, eight directions. */
static const int k_cos[8] = { 4096, 2896, 0, -2896, -4096, -2896, 0, 2896 };
static const int k_sin[8] = { 0, 2896, 4096, 2896, 0, -2896, -4096, -2896 };

/**
 * @brief Pick a spot for one copy: a ring around the original, each
 *        candidate checked for space and line of sight, nearest ring first.
 * @return 1 and fills out[3], or 0 when nowhere around it is usable.
 */
static int place_copy(CPUState* cpu, const Moby* src, int nth, int32_t out[3])
{
    int start = (int)(rnd() & 7u);
    for (int ring = 0; ring < 2; ring++) {
        int radius = g_spread + ring * (g_spread / 2);
        for (int step = 0; step < 8; step++) {
            int k = (start + step * 3 + nth) & 7;
            int32_t x = src->m_Position.x + (int32_t)((int64_t)radius * k_cos[k] / 4096);
            int32_t y = src->m_Position.y + (int32_t)((int64_t)radius * k_sin[k] / 4096);
            int32_t z = src->m_Position.z;
            g_cand++;
            if (!spot_is_clear(cpu, src, x, y, z)) { g_rej_space++; continue; }
            if (!spot_in_sight(cpu, src, x, y, z)) { g_rej_sight++; continue; }
            out[0] = x; out[1] = y; out[2] = z;
            return 1;
        }
    }
    return 0;
}

static Moby* spawn_slot(CPUState* cpu, int cls, Moby* parent)
{
    const uint32_t* fn = (const uint32_t*)g_api->guest(OP_GADDR_g_SpawnMoby);
    int32_t* count = (int32_t*)g_api->guest(OP_GADDR_g_DynMobyCount);
    int32_t* max   = (int32_t*)g_api->guest(OP_GADDR_g_DynMobyMax);
    if (!fn || (*fn >> 24) != 0x80u || !count || !max) return NULL;
    /* func_800524C4 has no capacity check of its own, and the pool is also
     * where dropped gems and effects come from: leave room. */
    if (*count >= *max - g_reserve) return NULL;

    uint32_t a0 = cpu->a0, a1 = cpu->a1, v0 = cpu->v0;
    cpu->a0 = (uint32_t)cls;
    cpu->a1 = parent ? g_api->guest_addr(parent) : 0u;
    g_api->call(cpu, *fn);
    uint32_t ret = cpu->v0;
    cpu->a0 = a0; cpu->a1 = a1; cpu->v0 = v0;
    if ((ret >> 24) != 0x80u) return NULL;
    return (Moby*)g_api->guest(ret);
}

/** One copy of `src` at (x, y, z), carrying no gem. */
static Moby* clone_enemy(CPUState* cpu, Moby* src, uint32_t psize, const int32_t pos[3])
{
    Moby* m = spawn_slot(cpu, src->m_Class, src);
    if (!m) return NULL;

    uint32_t keep_props  = m->m_Props;
    uint32_t keep_chain  = m->m_CollisionChainNext;
    uint32_t keep_group  = m->m_CollisionGroup;
    short    keep_region = m->m_CollisionRegion;
    uint8_t  keep_sector = m->m_SectorIndex;
    uint8_t  keep_index  = m->m_MobyIndex;

    uint32_t own = arena_take(psize);
    void* dst = own ? g_api->guest(own) : NULL;
    const void* from = g_api->guest(src->m_Props);
    if (dst && from) memcpy(dst, from, psize);

    memcpy(m, src, sizeof *m);

    m->m_Props = (own && dst) ? own : keep_props;
    m->m_CollisionChainNext = keep_chain;
    m->m_CollisionGroup = keep_group;
    m->m_CollisionRegion = keep_region;
    m->m_SectorIndex = keep_sector;
    m->m_MobyIndex = keep_index;
    m->m_Pod = 0xFF;
    m->m_WasDrawn = 0;
    /* The gem stays with the original. m_DropMoby = 0xFF would NOT mean
     * "nothing": the death code treats a drop class outside 1..126 as
     * "pick a random wisp" (func at 0x8003ABF4). What it does honour is
     * m_DroppedFlag bit 0x80, "this one has already paid out", so the copy
     * keeps the class and is marked as already dropped. */
    m->m_DroppedFlag |= 0x80;

    m->m_Position.x = pos[0];
    m->m_Position.y = pos[1];
    m->m_Position.z = pos[2];
    return m;
}

/* ----------------------------------------------------------------------
 * MARKING THE GEM CARRIER
 *
 * The moby struct's own colour fields (m_SpecularMetalColor /
 * m_SpecularMetalType, with or without the shiny renderer bit) change
 * nothing on a normally shaded enemy - tried first, no visible difference.
 * So the tint is a material instead: one material on the moby channel
 * whose refine callback claims only the carriers and hands each the colour
 * drawn for it, and declines everything else so every other moby keeps
 * stock shading. The callback runs during extraction and may read host
 * state, which is where the carrier list lives.
 * ---------------------------------------------------------------------- */

enum { MAX_CARRIERS = 64 };
static uint32_t g_carrier[MAX_CARRIERS];     /**< Guest addresses.        */
static float    g_carrier_rgb[MAX_CARRIERS][3];
static int      g_carrier_n;
static int      g_tint_material = -1;

/** A saturated, clearly-not-stock colour: one channel low, one high. */
static void random_tint(float out[3])
{
    unsigned r = rnd();
    int hue = (int)(r % 6u);
    float hi = 1.35f + (float)((r >> 8) % 40u) / 100.0f;   /* 1.35 .. 1.74 */
    float lo = 0.35f + (float)((r >> 16) % 30u) / 100.0f;  /* 0.35 .. 0.64 */
    const int order[6][3] = {
        { 0, 1, 2 }, { 1, 0, 2 }, { 1, 2, 0 }, { 2, 1, 0 }, { 2, 0, 1 }, { 0, 2, 1 },
    };
    out[order[hue][0]] = hi;
    out[order[hue][1]] = 1.0f;
    out[order[hue][2]] = lo;
}

/** Extraction context, host state only: tint the carriers, pass the rest. */
static int tint_refine(const openpete_mod_material_key_t* key, void* out, uint32_t cap)
{
    if (!key || key->channel != OP_CHAN_MOBY || cap < 16u) return -1;
    for (int i = 0; i < g_carrier_n; i++) {
        if (g_carrier[i] != key->u.moby.vaddr) continue;
        float* v = (float*)out;
        v[0] = g_carrier_rgb[i][0];
        v[1] = g_carrier_rgb[i][1];
        v[2] = g_carrier_rgb[i][2];
        v[3] = 1.0f;                      /* full strength */
        return 16;
    }
    return -1;                            /* stock shading */
}

/** A random shade for the enemy that still carries the gem. */
static void mark_gem_carrier(Moby* m)
{
    if (!g_mark || g_carrier_n >= MAX_CARRIERS) return;
    g_carrier[g_carrier_n] = g_api->guest_addr(m);
    random_tint(g_carrier_rgb[g_carrier_n]);
    g_carrier_n++;
}

/** Remember one of the level's own enemies, for the count. */
static void track_original(Moby* m)
{
    if (g_track_n >= MAX_ENEMIES) return;
    g_track[g_track_n] = g_api->guest_addr(m);
    g_track_class[g_track_n] = m->m_Class;
    g_track_n++;
}

/** Remember one copy, to notice when the pool has been reset under us. */
static void track_copy(Moby* m)
{
    if (g_copy_n >= MAX_COPIES) return;
    g_copy[g_copy_n] = g_api->guest_addr(m);
    g_copy_class[g_copy_n] = m->m_Class;
    g_copy_dead[g_copy_n] = 0;
    g_copy_n++;
}

/** Copies still in their slots, dead ones included (they were fought for). */
static int copies_accounted(void)
{
    int n = 0;
    for (int i = 0; i < g_copy_n; i++) {
        const Moby* m = (const Moby*)g_api->guest(g_copy[i]);
        if (g_copy_dead[i] || (m && m->m_State != 0xFF && m->m_Class == g_copy_class[i]))
            n++;
    }
    return n;
}

/** Tick context: copy every enemy in the level. */
static void multiply_level(CPUState* cpu)
{
    Moby* mobys = level_mobys();
    if (!mobys) return;
    int n = level_moby_count(mobys);

    g_track_n = g_copy_n = g_killed = g_added = 0;
    g_carrier_n = 0;
    g_rej_space = g_rej_sight = g_cand = 0;
    g_arena_used = 24;                       /* the two collision vectors */

    int originals = 0, no_room = 0, no_slot = 0;
    for (int i = 0; i < n; i++) {
        Moby* src = &mobys[i];
        if (!is_enemy(src)) continue;
        originals++;
        track_original(src);
        if (g_mark) mark_gem_carrier(src);

        uint32_t psize = props_size(src, mobys, n);
        for (int c = 1; c < g_multiplier; c++) {
            int32_t pos[3];
            if (!place_copy(cpu, src, c, pos)) { no_room++; continue; }
            Moby* m = clone_enemy(cpu, src, psize, pos);
            if (!m) { no_slot++; continue; }   /* the pool's budget is spent */
            track_copy(m);
            g_added++;
        }
    }

    const int32_t* cnt = (const int32_t*)g_api->guest(OP_GADDR_g_DynMobyCount);
    const int32_t* mx  = (const int32_t*)g_api->guest(OP_GADDR_g_DynMobyMax);
    int pool_max = mx ? *mx : 0;
    g_dyn_after = cnt ? *cnt : 0;
    g_done = 1;

    g_api->log(g_self, OP_MOD_LOG_INFO,
               "level %d: %d enemies x%d -> %d copies added, %d with nowhere to "
               "stand, %d past the pool budget; pool at %d of %d; %d spots tried, "
               "%d had no room, %d out of sight",
               g_level, originals, g_multiplier, g_added, no_room, no_slot,
               g_dyn_after, pool_max, g_cand, g_rej_space, g_rej_sight);
    g_api->ui_status(g_self, "%d enemies, %d copies added%s", originals, g_added,
                     no_slot ? " (pool budget reached)" : "");
    if (g_added)
        g_api->notify(g_self, "gnorcs", 0, "%d extra enemies", g_added);
}

static int level_row(int id)
{
    for (int i = 0; i < LEVEL_ROWS; i++) if (k_levels[i].id == id) return i;
    return -1;
}

/** Levels cleared of enemies, and how many have any to clear. */
static void cleared_tally(int* done, int* total)
{
    int d = 0, t = 0;
    for (int i = 0; i < LEVEL_ROWS; i++) {
        if (!k_levels[i].total) continue;
        t++;
        d += g_level_cleared[i] != 0;
    }
    *done = d; *total = t;
}

/** The mod's own save file: one cleared level id per line. */
static void clear_path(char* out, size_t cap)
{
    const char* dir = g_api->data_dir(g_self);
    out[0] = 0;
    if (dir) snprintf(out, cap, "%s/cleared.txt", dir);
}

static void clear_load(void)
{
    char path[512];
    clear_path(path, sizeof path);
    if (!path[0]) return;
    FILE* f = fopen(path, "r");
    if (!f) return;
    int id;
    while (fscanf(f, "%d", &id) == 1) {
        int r = level_row(id);
        if (r >= 0) g_level_cleared[r] = 1;
    }
    fclose(f);
}

static void clear_save(void)
{
    char path[512];
    clear_path(path, sizeof path);
    if (!path[0]) { g_api->log(g_self, OP_MOD_LOG_WARN, "no data directory; clears are not saved"); return; }
    FILE* f = fopen(path, "w");
    if (!f) { g_api->log(g_self, OP_MOD_LOG_WARN, "cannot write %s", path); return; }
    for (int i = 0; i < LEVEL_ROWS; i++)
        if (g_level_cleared[i]) fprintf(f, "%d\n", k_levels[i].id);
    fclose(f);
}

/** The last enemy in this level just went down. */
static void on_level_cleared(void)
{
    if (g_this_level_row < 0 || g_level_cleared[g_this_level_row]) return;
    g_level_cleared[g_this_level_row] = 1;
    clear_save();

    int done, total;
    cleared_tally(&done, &total);
    g_banner_ticks = 150;                    /* about five seconds */
    g_api->notify(g_self, "cleared", 0, "every Gnorc down - %d of %d levels cleared",
                  done, total);
    g_api->log(g_self, OP_MOD_LOG_INFO,
               "level %d cleared of enemies (%d of %d levels)", g_level, done, total);
}

/**
 * @brief Hook on the game's completion percentage: it now wants the Gnorcs
 *        dead too.
 *
 * The game's own number already counts gems, dragons and eggs, so holding
 * it one short of its full value until every level is cleared is exactly
 * "gems, dragons AND enemies". The call lives in the menu and ending code
 * rather than the gameplay loop, so the log line says when it ran.
 */
static void on_completion(CPUState* cpu)
{
    g_api->base(cpu);
    int done, total;
    cleared_tally(&done, &total);
    if (!g_completion_hooked) {
        g_completion_hooked = 1;
        g_api->log(g_self, OP_MOD_LOG_INFO,
                   "completion asked for: %u%%, %d of %d levels cleared of enemies",
                   cpu->v0, done, total);
    }
    if (g_gate && done < total && (int32_t)cpu->v0 > 0) cpu->v0 -= 1;
}

/** A copy that is no longer itself: freed slot, or handed to something else. */
static int copy_gone(int i)
{
    const Moby* m = (const Moby*)g_api->guest(g_copy[i]);
    return !m || m->m_State == 0xFF || m->m_Class != g_copy_class[i];
}

/**
 * @brief Tick context: how many of the level's enemies are down, copies
 *        included.
 *
 * An original is dead when the game says so (m_State >= 0x80 is its own
 * "not active" test), which is also how it reads after a death: whatever
 * the game itself still counts as dead.
 *
 * A copy is latched the tick it dies, either in a death state or because
 * its slot has gone. The exception is the mass free: when a quarter of the
 * copies vanish on the same tick, the pool was thrown away rather than
 * fought through, so nothing is latched and the pass runs again from
 * scratch with a fresh set.
 */
static void update_kills(void)
{
    int killed = 0;
    for (int i = 0; i < g_track_n; i++) {
        const Moby* m = (const Moby*)g_api->guest(g_track[i]);
        if (!m || m->m_State >= 0x80 || m->m_Class != g_track_class[i]) killed++;
    }

    int vanished = 0;
    for (int i = 0; i < g_copy_n; i++)
        if (!g_copy_dead[i] && copy_gone(i)) vanished++;
    int mass_free = g_copy_n && vanished >= g_copy_n / 4 + 3;

    if (!mass_free) {
        for (int i = 0; i < g_copy_n; i++) {
            if (g_copy_dead[i]) continue;
            const Moby* m = (const Moby*)g_api->guest(g_copy[i]);
            if (copy_gone(i) || m->m_State >= 0x80) g_copy_dead[i] = 1;
        }
    }
    for (int i = 0; i < g_copy_n; i++) killed += g_copy_dead[i];

    int total = g_track_n + g_copy_n;
    int was = g_killed;
    g_killed = killed;
    if (total && killed == total && was < killed) on_level_cleared();

    if (!total)
        g_hud_text[0] = 0;
    else if (killed == total)
        snprintf(g_hud_text, sizeof g_hud_text, "GNORCS %d/%d  CLEARED", killed, total);
    else
        snprintf(g_hud_text, sizeof g_hud_text, "GNORCS %d/%d  %d%%",
                 killed, total, killed * 100 / total);
}

static int level_ok(void)
{
    const int32_t* id = (const int32_t*)g_api->guest(OP_GADDR_g_LevelId);
    if (!id) return 0;
    if (!g_flight_ok && *id % 10 == 5) return 0;      /* flight levels */
    return 1;
}

static void on_camera_update(CPUState* cpu)
{
    g_api->base(cpu);
    if (!in_gameplay()) return;

    const int32_t* id = (const int32_t*)g_api->guest(OP_GADDR_g_LevelId);
    if (id && *id != g_level) {
        g_level = *id;
        g_this_level_row = level_row(g_level);
        g_banner_ticks = 0;
        g_ticks = 0;
        g_done = 0;
        g_track_n = g_killed = g_added = 0;
        g_hud_text[0] = 0;
    }
    g_ticks++;

    /* A death or a reload throws the dynamic pool away and the copies go
     * with it. Checking every so often is enough, and cheap. */
    if (g_done && g_copy_n && (g_ticks % 15) == 0) {
        int alive = copies_accounted();
        if (alive * 2 < g_copy_n) {
            g_done = 0;
            g_ticks = 0;
            if (g_debug)
                g_api->log(g_self, OP_MOD_LOG_INFO,
                           "only %d of %d copies left: the pool was reset, multiplying again",
                           alive, g_copy_n);
        }
    }

    if (g_req_redo) { g_req_redo = 0; g_done = 0; g_ticks = SETTLE_TICKS; }

    /* The pass runs even at a multiplier of 1, where it adds nothing: the
     * counter and the level's cleared state are worth having on their own. */
    if (!g_done && g_ticks >= SETTLE_TICKS && level_ok())
        multiply_level(cpu);

    if (g_done) update_kills();
    if (g_banner_ticks > 0) g_banner_ticks--;
}

static void on_present(const openpete_present_ctx_t* ctx)
{
    int down = g_api->binding_down(g_self, "redo");
    if (down && !g_redo_key_held) g_req_redo = 1;
    g_redo_key_held = down;

    if (!ctx) return;

    if (g_hud && g_hud_text[0]) {
        /* draw_text has no measuring call, so the width is estimated from
         * the glyph advance: 0.85 of the cap height per character, measured
         * off a capture ("GNORCS 0/33 0%", 14 characters, spanning 0.40 of
         * the window height at cap 0.034). */
        const float cap = 0.034f, margin = 0.03f;
        float w = (float)strlen(g_hud_text) * cap * 0.85f;
        float x = margin;
        if (g_hud_anchor == 1) x = ctx->aspect * 0.5f - w * 0.5f;
        else if (g_hud_anchor == 2) x = ctx->aspect - margin - w;
        if (x < margin) x = margin;
        g_api->draw_text(x, 0.94f, cap, 0x605010u, g_hud_text);
    }

    /* The clear banner: five seconds, blinking, in the middle of the
     * screen where nothing else lives. */
    if (g_banner_ticks > 0 && (ctx->tick / 8u) % 2u == 0u) {
        int done, total;
        cleared_tally(&done, &total);
        char line[64];
        snprintf(line, sizeof line, "LEVELS CLEARED  %d/%d", done, total);
        g_api->draw_text(ctx->aspect * 0.5f - 0.30f, 0.36f, 0.075f, 0x80B030u,
                         "ALL GNORCS DOWN");
        g_api->draw_text(ctx->aspect * 0.5f - 0.19f, 0.54f, 0.034f, 0x605010u, line);
    }
}

int openpete_mod_entry(const openpete_mod_api_t* api, openpete_mod_t* self)
{
    g_api = api; g_self = self;

    g_multiplier = (int)api->config_int(self, "enemy.multiplier", 2);
    g_spread     = (int)api->config_int(self, "enemy.spread", 1400);
    g_reserve    = (int)api->config_int(self, "enemy.reserve", 25);
    g_mark       = (int)api->config_int(self, "enemy.mark", 1);
    g_hud        = (int)api->config_bool(self, "enemy.hud", 1);
    g_flight_ok  = (int)api->config_bool(self, "enemy.flight_levels", 0);
    g_gate       = (int)api->config_bool(self, "enemy.gate_completion", 1);
    {
        char where[32];
        api->config_str(self, "enemy.hud_position", "bottom-right", where, sizeof where);
        g_hud_anchor = !strcmp(where, "bottom-left") ? 0
                     : !strcmp(where, "bottom-center") ? 1 : 2;
    }
    g_debug      = (int)api->config_bool(self, "debug.log", 0);
    if (g_multiplier < 1) g_multiplier = 1;
    if (g_multiplier > 6) g_multiplier = 6;

    g_arena_size = 32u * 1024u;
    void* host = NULL;
    g_arena = api->guest_alloc(self, g_arena_size, 4u, 0u, &host);
    if (g_arena) {
        g_vec_a = g_arena;
        g_vec_b = g_arena + 12u;
        g_arena_used = 24u;
    } else {
        api->log(self, OP_MOD_LOG_WARN,
                 "no guest arena: copies would share the original's state; standing down");
        g_multiplier = 1;
    }

    if (g_mark) {
        int shader = api->shader_register(self, "shaders/gem_tint.frag");
        openpete_mod_material_selector_t sel = {
            sizeof sel, OP_CHAN_MOBY, -1, -1, -1, -1, 0u
        };
        g_tint_material = shader >= 0
            ? api->material_register_refine(self, &sel, shader, tint_refine) : -1;
        if (g_tint_material < 0)
            api->log(self, OP_MOD_LOG_WARN,
                     "gem carriers will not be tinted (see .build/shaders/gem_tint.frag.log)");
        else
            api->material_enable(self, g_tint_material, 1);
    }

    clear_load();
    {
        int done, total;
        cleared_tally(&done, &total);
        api->log(self, OP_MOD_LOG_INFO, "%d of %d levels cleared of enemies so far",
                 done, total);
    }
    if (g_gate && api->override_addr(self, FN_COMPLETION, on_completion) != 0)
        api->log(self, OP_MOD_LOG_WARN,
                 "completion hook refused; 100%% will not ask for the Gnorcs");

    if (api->override_name(self, "CameraUpdate", on_camera_update) != 0)
        api->log(self, OP_MOD_LOG_ERROR, "CameraUpdate override refused; nothing will spawn");
    api->register_present_hook(self, on_present);

    api->ui_status(self, "multiplier x%d", g_multiplier);
    return 0;
}
